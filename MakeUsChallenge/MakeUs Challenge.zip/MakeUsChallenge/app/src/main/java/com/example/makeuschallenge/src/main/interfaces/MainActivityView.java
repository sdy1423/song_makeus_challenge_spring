package com.example.makeuschallenge.src.main.interfaces;

public interface MainActivityView {
}
