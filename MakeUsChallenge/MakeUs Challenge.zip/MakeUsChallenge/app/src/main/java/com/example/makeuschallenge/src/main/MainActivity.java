package com.example.makeuschallenge.src.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.makeuschallenge.R;
import com.example.makeuschallenge.src.BaseActivity;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
