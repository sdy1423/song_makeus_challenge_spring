package com.example.makeuschallenge.src.main.models;

public class DefaultResponse {


}
